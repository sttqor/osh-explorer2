import { useState } from "react";

// ─── DATA ───────────────────────────────────────────────────────────────────

const PLACES = [
  { id: 1, name: "Сулайман-Тоо", category: "Природа", emoji: "⛰️", xp: 150, color: "#7C5C3A", bg: "#FFF4E6", locked: false,
    tasks: ["Подняться на вершину", "Найти петроглифы", "Сфотографировать закат"] },
  { id: 2, name: "Базар Джайма", category: "Культура", emoji: "🛒", xp: 80, color: "#2E7D6E", bg: "#E6F7F4", locked: false,
    tasks: ["Попробовать самсу", "Найти ряд специй", "Поторговаться"] },
  { id: 3, name: "Мечеть Равзат", category: "История", emoji: "🕌", xp: 100, color: "#5B4A8A", bg: "#F0ECFB", locked: false,
    tasks: ["Изучить архитектуру", "Узнать историю"] },
  { id: 4, name: "Парк Победы", category: "Природа", emoji: "🌳", xp: 60, color: "#3A7A3A", bg: "#EAF5EA", locked: true,
    tasks: ["Найти фонтан", "Познакомиться с местным", "Сделать пикник"] },
  { id: 5, name: "Река Ак-Буура", category: "Природа", emoji: "🌊", xp: 90, color: "#1A6B9A", bg: "#E6F2FA", locked: true,
    tasks: ["Пройти 1 км по берегу", "Найти мост с замками", "Увидеть рассвет"] },
  { id: 6, name: "Старый город", category: "История", emoji: "🏘️", xp: 120, color: "#9A5A1A", bg: "#FAF2E6", locked: true,
    tasks: ["Найти дом 100+ лет", "Попробовать чай в чайхане", "Сфоткать ворота"] },
];

const CHALLENGES = [
  { id: 1, title: "Утренний Ош", desc: "Посети 2 места до 9 утра", emoji: "🌅", xp: 200, days: 2, done: false },
  { id: 2, title: "Фуд-тур", desc: "Попробуй 3 блюда на базаре", emoji: "🍽️", xp: 150, days: 5, done: false },
  { id: 3, title: "Фотоохота", desc: "Сделай фото в 4 разных местах", emoji: "📸", xp: 180, days: 3, done: true },
];

const FEED = [
  { id: 1, user: "Айгерим", avatar: "👩", place: "Сулайман-Тоо", time: "2 часа назад", emoji: "⛰️", likes: 14, color: "#7C5C3A" },
  { id: 2, user: "Бакыт", avatar: "👦", place: "Базар Джайма", time: "5 часов назад", emoji: "🛒", likes: 8, color: "#2E7D6E" },
  { id: 3, user: "Нурзат", avatar: "👩", place: "Мечеть Равзат", time: "вчера", emoji: "🕌", likes: 21, color: "#5B4A8A" },
  { id: 4, user: "Эрлан", avatar: "👦", place: "Старый город", time: "вчера", emoji: "🏘️", likes: 6, color: "#9A5A1A" },
];

const LEADERBOARD = [
  { rank: 1, user: "Айгерим", xp: 640, avatar: "👩" },
  { rank: 2, user: "Нурзат", xp: 510, avatar: "👩" },
  { rank: 3, user: "Ты", xp: 310, avatar: "🧭", isMe: true },
  { rank: 4, user: "Бакыт", xp: 280, avatar: "👦" },
  { rank: 5, user: "Эрлан", xp: 190, avatar: "👦" },
];

// ─── CALENDAR DATA ───────────────────────────────────────────────────────────
const CALENDAR_DAYS = Array.from({ length: 30 }, (_, i) => ({
  day: i + 1,
  hasVisit: [1,3,5,8,10,12,15,17,19,21].includes(i + 1),
  place: ["Сулайман-Тоо","Базар Джайма","Мечеть Равзат","Парк"][Math.floor(Math.random()*4)],
  emoji: ["⛰️","🛒","🕌","🌳"][Math.floor(Math.random()*4)],
}));

// ─── COMPONENTS ──────────────────────────────────────────────────────────────

function Celebration({ ach, onClose }) {
  return (
    <div onClick={onClose} style={{
      position:"fixed",inset:0,zIndex:200,display:"flex",alignItems:"center",justifyContent:"center",
      background:"rgba(0,0,0,0.6)",backdropFilter:"blur(6px)"
    }}>
      <div style={{
        background:"white",borderRadius:28,padding:"44px 36px",textAlign:"center",
        animation:"pop .4s cubic-bezier(.36,1.6,.5,1)",
        boxShadow:"0 24px 64px rgba(0,0,0,0.3)",maxWidth:300,width:"90%"
      }}>
        <div style={{fontSize:70,marginBottom:14}}>{ach.emoji}</div>
        <div style={{fontSize:11,fontWeight:800,letterSpacing:3,color:"#E86A2A",textTransform:"uppercase",marginBottom:6}}>+{ach.xp} XP</div>
        <div style={{fontSize:24,fontWeight:900,color:"#1A1A1A",marginBottom:8}}>{ach.title}</div>
        <div style={{color:"#888",fontSize:14,lineHeight:1.5}}>{ach.desc}</div>
        <div style={{marginTop:20,fontSize:12,color:"#bbb"}}>нажми чтобы закрыть</div>
      </div>
    </div>
  );
}

// ─── PAGE 1: HOME ─────────────────────────────────────────────────────────────
function HomePage({ totalXP, streak, visitedCount, completedTasks, onOpenPlace }) {
  const levelInfo = totalXP < 100 ? {level:1,title:"Турист",next:100}
    : totalXP < 300 ? {level:2,title:"Путешественник",next:300}
    : totalXP < 600 ? {level:3,title:"Знаток",next:600}
    : {level:4,title:"Легенда Оша",next:600};
  const progress = Math.min((totalXP / levelInfo.next)*100, 100);

  const todayPlace = PLACES[1]; // Bazaar as daily suggestion

  return (
    <div style={{padding:"0 0 24px"}}>
      {/* Hero greeting */}
      <div style={{
        background:"linear-gradient(160deg, #1A1A2E 0%, #3A2A5A 50%, #7C3A1A 100%)",
        padding:"32px 20px 28px", position:"relative", overflow:"hidden"
      }}>
        <div style={{position:"absolute",top:-40,right:-40,width:160,height:160,borderRadius:"50%",
          background:"rgba(255,255,255,0.04)"}} />
        <div style={{position:"absolute",bottom:-20,left:-20,width:100,height:100,borderRadius:"50%",
          background:"rgba(255,255,255,0.03)"}} />
        <div style={{fontSize:13,color:"rgba(255,255,255,0.6)",marginBottom:4}}>Воскресенье, 21 июня</div>
        <div style={{fontSize:26,fontWeight:900,color:"white",marginBottom:2}}>Привет, исследователь 👋</div>
        <div style={{fontSize:14,color:"rgba(255,255,255,0.7)",marginBottom:24}}>Ош ждёт тебя сегодня</div>

        {/* XP bar */}
        <div style={{background:"rgba(255,255,255,0.1)",borderRadius:16,padding:"14px 16px"}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10}}>
            <div style={{display:"flex",alignItems:"center",gap:8}}>
              <div style={{
                width:30,height:30,borderRadius:"50%",
                background:"linear-gradient(135deg,#E86A2A,#D4A03A)",
                display:"flex",alignItems:"center",justifyContent:"center",
                color:"white",fontWeight:900,fontSize:13
              }}>{levelInfo.level}</div>
              <div>
                <div style={{color:"white",fontWeight:700,fontSize:13}}>{levelInfo.title}</div>
                <div style={{color:"rgba(255,255,255,0.5)",fontSize:11}}>{totalXP}/{levelInfo.next} XP</div>
              </div>
            </div>
            <div style={{display:"flex",gap:16}}>
              <div style={{textAlign:"center"}}>
                <div style={{color:"#FF6B35",fontWeight:900,fontSize:18}}>🔥{streak}</div>
                <div style={{color:"rgba(255,255,255,0.5)",fontSize:10}}>стрик</div>
              </div>
              <div style={{textAlign:"center"}}>
                <div style={{color:"#A78BFA",fontWeight:900,fontSize:18}}>📍{visitedCount}</div>
                <div style={{color:"rgba(255,255,255,0.5)",fontSize:10}}>мест</div>
              </div>
            </div>
          </div>
          <div style={{height:8,background:"rgba(255,255,255,0.15)",borderRadius:4,overflow:"hidden"}}>
            <div style={{height:"100%",width:`${progress}%`,
              background:"linear-gradient(90deg,#E86A2A,#D4A03A)",
              borderRadius:4,transition:"width .5s ease"}} />
          </div>
        </div>
      </div>

      <div style={{padding:"20px 16px 0"}}>
        {/* Daily challenge */}
        <div style={{
          background:"linear-gradient(135deg,#E86A2A,#C85A1A)",
          borderRadius:20,padding:"18px 18px",marginBottom:20,
          display:"flex",alignItems:"center",gap:16
        }}>
          <div style={{fontSize:40}}>🌅</div>
          <div style={{flex:1}}>
            <div style={{fontSize:11,color:"rgba(255,255,255,0.7)",fontWeight:700,letterSpacing:1,textTransform:"uppercase",marginBottom:2}}>Задание дня</div>
            <div style={{color:"white",fontWeight:800,fontSize:16,marginBottom:2}}>Утренний Ош</div>
            <div style={{color:"rgba(255,255,255,0.8)",fontSize:12}}>Посети 2 места до 9:00 · +200 XP</div>
          </div>
          <div style={{color:"white",fontSize:22}}>→</div>
        </div>

        {/* Suggested place */}
        <div style={{fontWeight:800,fontSize:17,marginBottom:14,color:"#1A1A1A"}}>Сегодня сходи сюда</div>
        <div onClick={() => onOpenPlace(todayPlace)} style={{
          background:"white",borderRadius:20,overflow:"hidden",
          boxShadow:"0 4px 20px rgba(0,0,0,0.08)",marginBottom:20,cursor:"pointer"
        }}>
          <div style={{
            background:`linear-gradient(135deg, ${todayPlace.bg}, ${todayPlace.color}22)`,
            padding:"24px 20px",display:"flex",alignItems:"center",gap:16
          }}>
            <div style={{fontSize:52}}>{todayPlace.emoji}</div>
            <div>
              <div style={{fontSize:20,fontWeight:900}}>{todayPlace.name}</div>
              <div style={{color:todayPlace.color,fontWeight:600,fontSize:13,marginBottom:6}}>{todayPlace.category}</div>
              <div style={{display:"flex",gap:8}}>
                <span style={{background:todayPlace.color,color:"white",borderRadius:10,padding:"3px 10px",fontSize:11,fontWeight:700}}>+{todayPlace.xp} XP</span>
                <span style={{background:"#F0F0F0",color:"#555",borderRadius:10,padding:"3px 10px",fontSize:11}}>{todayPlace.tasks.length} задания</span>
              </div>
            </div>
          </div>
          <div style={{padding:"14px 20px",background:"white"}}>
            <div style={{fontSize:13,color:"#666"}}>Один из крупнейших рынков Центральной Азии. Тут можно найти всё что угодно.</div>
          </div>
        </div>

        {/* Quick stats */}
        <div style={{fontWeight:800,fontSize:17,marginBottom:12,color:"#1A1A1A"}}>Твой прогресс</div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
          {[
            {label:"Мест посещено",value:`${visitedCount}/${PLACES.length}`,emoji:"📍",color:"#5B4A8A",bg:"#F0ECFB"},
            {label:"XP заработано",value:totalXP,emoji:"⚡",color:"#E86A2A",bg:"#FFF4E6"},
            {label:"Стрик",value:`${streak} дней`,emoji:"🔥",color:"#D4380D",bg:"#FFF1EC"},
            {label:"Уровень",value:levelInfo.level,emoji:"🏅",color:"#2E7D6E",bg:"#E6F7F4"},
          ].map(s => (
            <div key={s.label} style={{background:s.bg,borderRadius:18,padding:"16px 14px"}}>
              <div style={{fontSize:24,marginBottom:6}}>{s.emoji}</div>
              <div style={{fontWeight:900,fontSize:22,color:s.color}}>{s.value}</div>
              <div style={{fontSize:11,color:"#888",marginTop:2}}>{s.label}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── PAGE 2: MAP / GAME ───────────────────────────────────────────────────────
function MapPage({ visited, completedTasks, onOpenPlace }) {
  const [view, setView] = useState("game"); // "game" | "map"

  return (
    <div style={{padding:"0 0 24px"}}>
      <div style={{padding:"20px 16px 0"}}>
        <div style={{fontWeight:900,fontSize:22,marginBottom:4}}>Карта Оша</div>
        <div style={{color:"#888",fontSize:13,marginBottom:16}}>Открывай новые места</div>

        {/* Toggle */}
        <div style={{
          display:"flex",background:"#F0EBE3",borderRadius:14,padding:4,marginBottom:20
        }}>
          {[{id:"game",label:"🎮 Игра"},{id:"map",label:"🗺️ Маршрут"}].map(t => (
            <button key={t.id} onClick={() => setView(t.id)} style={{
              flex:1,padding:"10px",borderRadius:10,border:"none",cursor:"pointer",
              background: view===t.id ? "white" : "transparent",
              fontWeight: view===t.id ? 700 : 400,
              color: view===t.id ? "#1A1A1A" : "#888",
              boxShadow: view===t.id ? "0 2px 8px rgba(0,0,0,0.1)" : "none",
              fontSize:14,transition:"all .2s"
            }}>{t.label}</button>
          ))}
        </div>

        {view === "game" && (
          <>
            {/* Duolingo-style path */}
            <div style={{position:"relative",paddingBottom:16}}>
              {PLACES.map((place, i) => {
                const isVisited = visited[place.id];
                const doneTasks = place.tasks.filter((_,ti) => completedTasks[`${place.id}-${ti}`]).length;
                const progress = (doneTasks/place.tasks.length)*100;
                const isLeft = i % 2 === 0;

                return (
                  <div key={place.id} style={{
                    display:"flex",
                    flexDirection: isLeft ? "row" : "row-reverse",
                    alignItems:"center",
                    marginBottom: i < PLACES.length-1 ? 0 : 0,
                    position:"relative"
                  }}>
                    {/* Connector line */}
                    {i < PLACES.length-1 && (
                      <div style={{
                        position:"absolute",
                        [isLeft ? "left" : "right"]: 48,
                        top: 72,
                        width: 3,
                        height: 60,
                        background: isVisited ? place.color : "#E0D8D0",
                        borderRadius: 2,
                        zIndex: 0
                      }} />
                    )}

                    {/* Node */}
                    <div onClick={() => !place.locked && onOpenPlace(place)}
                      style={{
                        width:80,height:80,borderRadius:"50%",flexShrink:0,
                        background: place.locked ? "#E8E0D8"
                          : isVisited ? `linear-gradient(135deg, ${place.color}, ${place.color}CC)`
                          : "white",
                        border: place.locked ? "3px solid #D0C8C0"
                          : isVisited ? `3px solid ${place.color}`
                          : `3px solid ${place.color}`,
                        display:"flex",alignItems:"center",justifyContent:"center",
                        fontSize: place.locked ? 24 : 36,
                        cursor: place.locked ? "default" : "pointer",
                        boxShadow: !place.locked ? `0 4px 20px ${place.color}44` : "none",
                        zIndex:1,position:"relative",
                        filter: place.locked ? "grayscale(1) opacity(0.5)" : "none",
                        transition:"transform .15s",
                      }}>
                      {place.locked ? "🔒" : place.emoji}
                      {isVisited && (
                        <div style={{
                          position:"absolute",top:-4,right:-4,
                          background:"#22C55E",borderRadius:"50%",
                          width:22,height:22,display:"flex",alignItems:"center",justifyContent:"center",
                          color:"white",fontSize:12,fontWeight:700,border:"2px solid white"
                        }}>✓</div>
                      )}
                    </div>

                    {/* Info card */}
                    <div style={{
                      flex:1,margin: isLeft ? "0 0 0 16px" : "0 16px 0 0",
                      background:"white",borderRadius:16,padding:"12px 14px",
                      marginBottom:40,
                      opacity: place.locked ? 0.5 : 1,
                      boxShadow:"0 2px 12px rgba(0,0,0,0.06)"
                    }}>
                      <div style={{fontWeight:800,fontSize:14,color: place.locked ? "#888" : "#1A1A1A"}}>{place.name}</div>
                      <div style={{fontSize:11,color:place.locked?"#aaa":place.color,fontWeight:600,marginBottom:6}}>
                        {place.locked ? "Закрыто" : `+${place.xp} XP · ${place.category}`}
                      </div>
                      {!place.locked && (
                        <div style={{height:5,background:"#F0F0F0",borderRadius:3,overflow:"hidden"}}>
                          <div style={{height:"100%",width:`${progress}%`,background:place.color,borderRadius:3,transition:"width .5s"}} />
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </>
        )}

        {view === "map" && (
          <div>
            {/* Fake map */}
            <div style={{
              background:"linear-gradient(145deg,#C8E6C9,#A5D6A7)",
              borderRadius:20,height:200,marginBottom:16,
              display:"flex",alignItems:"center",justifyContent:"center",
              position:"relative",overflow:"hidden",
              boxShadow:"0 4px 20px rgba(0,0,0,0.1)"
            }}>
              <div style={{position:"absolute",top:"30%",left:"40%",textAlign:"center"}}>
                <div style={{fontSize:32}}>⛰️</div>
                <div style={{fontSize:10,fontWeight:700,background:"white",borderRadius:8,padding:"2px 8px"}}>Сулайман-Тоо</div>
              </div>
              <div style={{position:"absolute",top:"55%",left:"55%",textAlign:"center"}}>
                <div style={{fontSize:24}}>🛒</div>
                <div style={{fontSize:10,fontWeight:700,background:"white",borderRadius:8,padding:"2px 8px"}}>Джайма</div>
              </div>
              <div style={{position:"absolute",top:"40%",left:"20%",textAlign:"center"}}>
                <div style={{fontSize:24}}>🕌</div>
                <div style={{fontSize:10,fontWeight:700,background:"white",borderRadius:8,padding:"2px 8px"}}>Равзат</div>
              </div>
              <div style={{position:"absolute",top:"65%",left:"30%",textAlign:"center"}}>
                <div style={{fontSize:20}}>🌊</div>
              </div>
              {/* Route line visual */}
              <svg style={{position:"absolute",inset:0,width:"100%",height:"100%",pointerEvents:"none"}}>
                <polyline points="160,80 220,110 80,80" stroke="#E86A2A" strokeWidth="2" strokeDasharray="6,4" fill="none" opacity="0.6"/>
              </svg>
            </div>

            <div style={{fontWeight:700,fontSize:14,marginBottom:10,color:"#555"}}>РЕКОМЕНДУЕМЫЙ МАРШРУТ</div>
            {[
              {step:1,name:"Базар Джайма",time:"10:00",emoji:"🛒",dur:"1.5 часа"},
              {step:2,name:"Мечеть Равзат",time:"12:00",emoji:"🕌",dur:"45 мин"},
              {step:3,name:"Сулайман-Тоо",time:"13:30",emoji:"⛰️",dur:"2 часа"},
            ].map(s => (
              <div key={s.step} style={{
                display:"flex",alignItems:"center",gap:12,
                background:"white",borderRadius:16,padding:"14px 16px",marginBottom:8,
                boxShadow:"0 2px 10px rgba(0,0,0,0.05)"
              }}>
                <div style={{
                  width:32,height:32,borderRadius:"50%",
                  background:"linear-gradient(135deg,#E86A2A,#D4A03A)",
                  display:"flex",alignItems:"center",justifyContent:"center",
                  color:"white",fontWeight:800,fontSize:13,flexShrink:0
                }}>{s.step}</div>
                <div style={{fontSize:24}}>{s.emoji}</div>
                <div style={{flex:1}}>
                  <div style={{fontWeight:700,fontSize:14}}>{s.name}</div>
                  <div style={{fontSize:12,color:"#888"}}>{s.time} · {s.dur}</div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// ─── PAGE 3: COMMUNITY + CHALLENGES ──────────────────────────────────────────
function CommunityPage() {
  const [tab, setTab] = useState("feed");
  const [liked, setLiked] = useState({});

  return (
    <div style={{padding:"0 0 24px"}}>
      <div style={{padding:"20px 16px 0"}}>
        <div style={{fontWeight:900,fontSize:22,marginBottom:4}}>Сообщество</div>

        <div style={{display:"flex",background:"#F0EBE3",borderRadius:14,padding:4,marginBottom:20}}>
          {[{id:"feed",label:"📸 Лента"},{id:"challenges",label:"⚡ Испытания"},{id:"top",label:"🏆 Топ"}].map(t => (
            <button key={t.id} onClick={() => setTab(t.id)} style={{
              flex:1,padding:"9px 4px",borderRadius:10,border:"none",cursor:"pointer",
              background: tab===t.id ? "white" : "transparent",
              fontWeight: tab===t.id ? 700 : 400,
              color: tab===t.id ? "#1A1A1A" : "#888",
              boxShadow: tab===t.id ? "0 2px 8px rgba(0,0,0,0.1)" : "none",
              fontSize:12,transition:"all .2s"
            }}>{t.label}</button>
          ))}
        </div>

        {tab === "feed" && FEED.map(post => (
          <div key={post.id} style={{background:"white",borderRadius:20,marginBottom:12,overflow:"hidden",boxShadow:"0 2px 12px rgba(0,0,0,0.06)"}}>
            {/* Fake photo */}
            <div style={{
              height:160,
              background:`linear-gradient(160deg, ${post.color}33, ${post.color}88)`,
              display:"flex",alignItems:"center",justifyContent:"center",
              fontSize:64,position:"relative"
            }}>
              {post.emoji}
              <div style={{
                position:"absolute",bottom:10,left:12,
                background:"rgba(0,0,0,0.4)",borderRadius:10,
                padding:"4px 10px",color:"white",fontSize:11,fontWeight:600
              }}>{post.place}</div>
            </div>
            <div style={{padding:"12px 14px"}}>
              <div style={{display:"flex",alignItems:"center",justifyContent:"space-between"}}>
                <div style={{display:"flex",alignItems:"center",gap:8}}>
                  <div style={{fontSize:24}}>{post.avatar}</div>
                  <div>
                    <div style={{fontWeight:700,fontSize:14}}>{post.user}</div>
                    <div style={{fontSize:11,color:"#888"}}>{post.time}</div>
                  </div>
                </div>
                <button onClick={() => setLiked(p => ({...p,[post.id]:!p[post.id]}))} style={{
                  background:"none",border:"none",cursor:"pointer",
                  display:"flex",alignItems:"center",gap:4,
                  color: liked[post.id] ? "#E86A2A" : "#888",fontWeight:700,fontSize:13
                }}>
                  {liked[post.id] ? "❤️" : "🤍"} {post.likes + (liked[post.id]?1:0)}
                </button>
              </div>
            </div>
          </div>
        ))}

        {tab === "challenges" && (
          <>
            <div style={{
              background:"linear-gradient(135deg,#1A1A2E,#3A2A5A)",
              borderRadius:20,padding:18,marginBottom:16,color:"white"
            }}>
              <div style={{fontSize:11,fontWeight:700,letterSpacing:2,color:"rgba(255,255,255,0.5)",textTransform:"uppercase",marginBottom:6}}>Эта неделя</div>
              <div style={{fontSize:20,fontWeight:900,marginBottom:4}}>Неделя открытий</div>
              <div style={{fontSize:13,color:"rgba(255,255,255,0.7)"}}>Выполни все испытания — получи бонус 500 XP</div>
            </div>

            {CHALLENGES.map(ch => (
              <div key={ch.id} style={{
                background:"white",borderRadius:20,padding:16,marginBottom:10,
                display:"flex",gap:14,alignItems:"center",
                border: ch.done ? "2px solid #22C55E" : "2px solid transparent",
                boxShadow:"0 2px 12px rgba(0,0,0,0.06)"
              }}>
                <div style={{
                  width:52,height:52,borderRadius:16,
                  background: ch.done ? "#DCFCE7" : "#FFF4E6",
                  display:"flex",alignItems:"center",justifyContent:"center",
                  fontSize:28,flexShrink:0
                }}>{ch.emoji}</div>
                <div style={{flex:1}}>
                  <div style={{fontWeight:800,fontSize:15,marginBottom:2}}>{ch.title}</div>
                  <div style={{fontSize:12,color:"#777",marginBottom:6}}>{ch.desc}</div>
                  <div style={{display:"flex",gap:8,alignItems:"center"}}>
                    <span style={{fontSize:12,fontWeight:700,color:"#E86A2A"}}>+{ch.xp} XP</span>
                    {!ch.done && <span style={{fontSize:11,color:"#888"}}>осталось {ch.days} дня</span>}
                    {ch.done && <span style={{fontSize:11,color:"#22C55E",fontWeight:700}}>✓ Выполнено!</span>}
                  </div>
                </div>
              </div>
            ))}
          </>
        )}

        {tab === "top" && (
          <>
            <div style={{fontWeight:700,fontSize:13,color:"#888",letterSpacing:1,textTransform:"uppercase",marginBottom:14}}>Топ этой недели</div>
            {LEADERBOARD.map(entry => (
              <div key={entry.rank} style={{
                background: entry.isMe ? "linear-gradient(135deg,#FFF4E6,#FFF1E0)" : "white",
                borderRadius:18,padding:"14px 16px",marginBottom:8,
                display:"flex",alignItems:"center",gap:14,
                border: entry.isMe ? "2px solid #E86A2A" : "2px solid transparent",
                boxShadow:"0 2px 10px rgba(0,0,0,0.05)"
              }}>
                <div style={{
                  width:32,height:32,borderRadius:"50%",
                  background: entry.rank===1 ? "linear-gradient(135deg,#FFD700,#FFA500)"
                    : entry.rank===2 ? "linear-gradient(135deg,#C0C0C0,#A0A0A0)"
                    : entry.rank===3 ? "linear-gradient(135deg,#CD7F32,#B8682A)"
                    : "#F0EBE3",
                  display:"flex",alignItems:"center",justifyContent:"center",
                  fontWeight:900,fontSize:13,
                  color: entry.rank<=3 ? "white" : "#888"
                }}>{entry.rank}</div>
                <div style={{fontSize:28}}>{entry.avatar}</div>
                <div style={{flex:1}}>
                  <div style={{fontWeight:700,fontSize:14,color: entry.isMe ? "#E86A2A" : "#1A1A1A"}}>
                    {entry.user} {entry.isMe && "← ты"}
                  </div>
                </div>
                <div style={{fontWeight:900,fontSize:16,color:"#5B4A8A"}}>⚡{entry.xp}</div>
              </div>
            ))}
          </>
        )}
      </div>
    </div>
  );
}

// ─── PAGE 4: PROFILE ──────────────────────────────────────────────────────────
function ProfilePage({ totalXP, streak, visitedCount, completedTasks }) {
  const [selectedDay, setSelectedDay] = useState(null);
  const levelInfo = totalXP < 100 ? {level:1,title:"Турист",next:100}
    : totalXP < 300 ? {level:2,title:"Путешественник",next:300}
    : totalXP < 600 ? {level:3,title:"Знаток",next:600}
    : {level:4,title:"Легенда Оша",next:600};
  const progress = Math.min((totalXP/levelInfo.next)*100,100);

  return (
    <div style={{padding:"0 0 24px"}}>
      {/* Profile header */}
      <div style={{
        background:"linear-gradient(160deg,#1A1A2E,#3A2A5A)",
        padding:"28px 20px 24px",textAlign:"center"
      }}>
        <div style={{
          width:72,height:72,borderRadius:"50%",
          background:"linear-gradient(135deg,#E86A2A,#5B4A8A)",
          margin:"0 auto 12px",display:"flex",alignItems:"center",justifyContent:"center",
          fontSize:36
        }}>🧭</div>
        <div style={{fontWeight:900,fontSize:22,color:"white",marginBottom:2}}>Исследователь</div>
        <div style={{color:"rgba(255,255,255,0.6)",fontSize:13,marginBottom:20}}>Уровень {levelInfo.level} · {levelInfo.title}</div>

        <div style={{background:"rgba(255,255,255,0.1)",borderRadius:14,padding:"10px 16px"}}>
          <div style={{display:"flex",justifyContent:"space-between",marginBottom:6}}>
            <span style={{fontSize:12,color:"rgba(255,255,255,0.7)",fontWeight:600}}>до следующего уровня</span>
            <span style={{fontSize:12,color:"#D4A03A",fontWeight:700}}>{levelInfo.next - totalXP} XP осталось</span>
          </div>
          <div style={{height:8,background:"rgba(255,255,255,0.15)",borderRadius:4,overflow:"hidden"}}>
            <div style={{height:"100%",width:`${progress}%`,
              background:"linear-gradient(90deg,#E86A2A,#D4A03A)",borderRadius:4}} />
          </div>
        </div>
      </div>

      <div style={{padding:"20px 16px 0"}}>
        {/* Stats row */}
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:10,marginBottom:24}}>
          {[
            {emoji:"📍",value:visitedCount,label:"Мест"},
            {emoji:"⚡",value:totalXP,label:"XP"},
            {emoji:"🔥",value:streak,label:"Стрик"},
          ].map(s => (
            <div key={s.label} style={{background:"white",borderRadius:16,padding:"14px 10px",textAlign:"center",boxShadow:"0 2px 10px rgba(0,0,0,0.05)"}}>
              <div style={{fontSize:22}}>{s.emoji}</div>
              <div style={{fontWeight:900,fontSize:22,color:"#1A1A1A"}}>{s.value}</div>
              <div style={{fontSize:11,color:"#888"}}>{s.label}</div>
            </div>
          ))}
        </div>

        {/* Calendar */}
        <div style={{fontWeight:800,fontSize:17,marginBottom:12,color:"#1A1A1A"}}>Мои прогулки</div>
        <div style={{background:"white",borderRadius:20,padding:16,marginBottom:16,boxShadow:"0 2px 12px rgba(0,0,0,0.06)"}}>
          <div style={{display:"grid",gridTemplateColumns:"repeat(7,1fr)",gap:4}}>
            {["Пн","Вт","Ср","Чт","Пт","Сб","Вс"].map(d => (
              <div key={d} style={{textAlign:"center",fontSize:10,color:"#888",fontWeight:600,paddingBottom:4}}>{d}</div>
            ))}
            {Array.from({length:2}).map((_,i) => <div key={`pad-${i}`}/>)}
            {CALENDAR_DAYS.map(d => (
              <div key={d.day} onClick={() => d.hasVisit && setSelectedDay(d)}
                style={{
                  aspectRatio:"1",borderRadius:10,
                  background: d.hasVisit ? "linear-gradient(135deg,#E86A2A,#D4A03A)" : "#F5F0EB",
                  display:"flex",alignItems:"center",justifyContent:"center",
                  fontSize: d.hasVisit ? 14 : 11,
                  fontWeight: d.hasVisit ? 700 : 400,
                  color: d.hasVisit ? "white" : "#AAA",
                  cursor: d.hasVisit ? "pointer" : "default",
                  transition:"transform .1s",
                }}>
                {d.hasVisit ? d.emoji : d.day}
              </div>
            ))}
          </div>

          {/* Day detail popup */}
          {selectedDay && (
            <div style={{
              marginTop:14,background:"#FFF4E6",borderRadius:14,padding:"12px 14px",
              display:"flex",alignItems:"center",gap:12
            }}>
              <div style={{fontSize:32}}>{selectedDay.emoji}</div>
              <div>
                <div style={{fontWeight:700,fontSize:14}}>{selectedDay.place}</div>
                <div style={{fontSize:12,color:"#888"}}>21 июня · Фото сохранено</div>
              </div>
              <button onClick={() => setSelectedDay(null)} style={{
                marginLeft:"auto",background:"none",border:"none",color:"#AAA",fontSize:18,cursor:"pointer"
              }}>✕</button>
            </div>
          )}
        </div>

        {/* Settings */}
        <div style={{fontWeight:800,fontSize:17,marginBottom:12,color:"#1A1A1A"}}>Настройки</div>
        <div style={{background:"white",borderRadius:20,overflow:"hidden",boxShadow:"0 2px 12px rgba(0,0,0,0.06)"}}>
          {[
            {icon:"🔔",label:"Уведомления"},
            {icon:"🌐",label:"Язык"},
            {icon:"🔒",label:"Приватность"},
            {icon:"❓",label:"Помощь"},
            {icon:"⭐",label:"Оценить приложение"},
          ].map((item,i,arr) => (
            <div key={item.label} style={{
              display:"flex",alignItems:"center",gap:14,
              padding:"16px 18px",
              borderBottom: i < arr.length-1 ? "1px solid #F5F0EB" : "none",
              cursor:"pointer"
            }}>
              <span style={{fontSize:20}}>{item.icon}</span>
              <span style={{flex:1,fontSize:14,fontWeight:500}}>{item.label}</span>
              <span style={{color:"#CCC",fontSize:18}}>›</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── PLACE MODAL ──────────────────────────────────────────────────────────────
function PlaceModal({ place, completedTasks, onToggle, onClose }) {
  const doneTasks = place.tasks.filter((_,i) => completedTasks[`${place.id}-${i}`]).length;
  return (
    <div onClick={onClose} style={{
      position:"fixed",inset:0,zIndex:50,background:"rgba(0,0,0,0.5)",
      display:"flex",alignItems:"flex-end"
    }}>
      <div onClick={e=>e.stopPropagation()} style={{
        background:"white",borderRadius:"24px 24px 0 0",width:"100%",
        padding:24,maxHeight:"80vh",overflowY:"auto"
      }}>
        <div style={{
          width:40,height:4,background:"#E0E0E0",borderRadius:2,
          margin:"0 auto 20px"
        }}/>
        <div style={{display:"flex",gap:14,marginBottom:16,alignItems:"center"}}>
          <div style={{
            width:60,height:60,borderRadius:18,background:place.bg,
            display:"flex",alignItems:"center",justifyContent:"center",fontSize:32,flexShrink:0
          }}>{place.emoji}</div>
          <div>
            <div style={{fontSize:22,fontWeight:900}}>{place.name}</div>
            <div style={{fontSize:13,color:place.color,fontWeight:600}}>{place.category} · +{place.xp} XP</div>
          </div>
        </div>
        <div style={{
          height:6,background:"#F0F0F0",borderRadius:3,overflow:"hidden",marginBottom:20
        }}>
          <div style={{height:"100%",width:`${(doneTasks/place.tasks.length)*100}%`,
            background:place.color,borderRadius:3,transition:"width .5s"}} />
        </div>
        <div style={{fontWeight:700,fontSize:12,color:"#888",letterSpacing:1,textTransform:"uppercase",marginBottom:10}}>Задания</div>
        {place.tasks.map((task,i) => {
          const done = completedTasks[`${place.id}-${i}`];
          return (
            <div key={i} onClick={() => onToggle(place.id,i)} style={{
              display:"flex",alignItems:"center",gap:12,padding:"14px 16px",
              background: done ? place.bg : "#F8F8F8",
              borderRadius:14,marginBottom:8,cursor:"pointer",
              border:`2px solid ${done ? place.color : "transparent"}`,
            }}>
              <div style={{
                width:26,height:26,borderRadius:"50%",flexShrink:0,
                background: done ? place.color : "#E0E0E0",
                display:"flex",alignItems:"center",justifyContent:"center"
              }}>
                {done && <span style={{color:"white",fontSize:13,fontWeight:700}}>✓</span>}
              </div>
              <span style={{fontSize:14,color: done ? place.color : "#444",fontWeight: done?600:400}}>{task}</span>
            </div>
          );
        })}
        <button onClick={onClose} style={{
          width:"100%",padding:14,background:place.color,color:"white",
          border:"none",borderRadius:16,fontSize:16,fontWeight:700,marginTop:8,cursor:"pointer"
        }}>Закрыть</button>
      </div>
    </div>
  );
}

// ─── APP ──────────────────────────────────────────────────────────────────────
export default function App() {
  const [tab, setTab] = useState("home");
  const [visited, setVisited] = useState({});
  const [completedTasks, setCompletedTasks] = useState({});
  const [totalXP, setTotalXP] = useState(310);
  const [selectedPlace, setSelectedPlace] = useState(null);
  const [celebration, setCelebration] = useState(null);
  const streak = 3;

  const visitedCount = Object.keys(visited).length;

  function toggleTask(placeId, taskIdx) {
    const key = `${placeId}-${taskIdx}`;
    const done = completedTasks[key];
    setCompletedTasks(p => ({...p,[key]:!done}));
    const place = PLACES.find(p=>p.id===placeId);
    const xpPer = Math.floor(place.xp/place.tasks.length);
    setTotalXP(p => p + (done ? -xpPer : xpPer));
    if (!visited[placeId]) setVisited(p => ({...p,[placeId]:true}));
  }

  const TABS = [
    {id:"home",emoji:"🏠",label:"Главная"},
    {id:"map",emoji:"🗺️",label:"Карта"},
    {id:"community",emoji:"👥",label:"Люди"},
    {id:"profile",emoji:"👤",label:"Профиль"},
  ];

  return (
    <div style={{fontFamily:"'Segoe UI',sans-serif",background:"#F5F0EB",minHeight:"100vh",maxWidth:420,margin:"0 auto",position:"relative"}}>
      {celebration && <Celebration ach={celebration} onClose={() => setCelebration(null)} />}
      {selectedPlace && (
        <PlaceModal
          place={selectedPlace}
          completedTasks={completedTasks}
          onToggle={toggleTask}
          onClose={() => setSelectedPlace(null)}
        />
      )}

      <div style={{overflowY:"auto",paddingBottom:80}}>
        {tab==="home" && <HomePage totalXP={totalXP} streak={streak} visitedCount={visitedCount} completedTasks={completedTasks} onOpenPlace={setSelectedPlace}/>}
        {tab==="map" && <MapPage visited={visited} completedTasks={completedTasks} onOpenPlace={setSelectedPlace}/>}
        {tab==="community" && <CommunityPage/>}
        {tab==="profile" && <ProfilePage totalXP={totalXP} streak={streak} visitedCount={visitedCount} completedTasks={completedTasks}/>}
      </div>

      {/* Bottom nav */}
      <div style={{
        position:"fixed",bottom:0,left:"50%",transform:"translateX(-50%)",
        width:"100%",maxWidth:420,background:"white",
        boxShadow:"0 -4px 24px rgba(0,0,0,0.1)",
        display:"flex",borderTop:"1px solid #F0EBE3",zIndex:40
      }}>
        {TABS.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} style={{
            flex:1,padding:"10px 0 8px",background:"none",border:"none",cursor:"pointer",
            display:"flex",flexDirection:"column",alignItems:"center",gap:2
          }}>
            <span style={{fontSize:22}}>{t.emoji}</span>
            <span style={{fontSize:10,fontWeight: tab===t.id?800:400,color: tab===t.id?"#E86A2A":"#888"}}>
              {t.label}
            </span>
            {tab===t.id && <div style={{width:4,height:4,borderRadius:"50%",background:"#E86A2A"}}/>}
          </button>
        ))}
      </div>

      <style>{`
        @keyframes pop {
          from { transform: scale(0.5); opacity: 0; }
          to { transform: scale(1); opacity: 1; }
        }
      `}</style>
    </div>
  );
}
